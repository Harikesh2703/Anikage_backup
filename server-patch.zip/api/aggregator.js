const allanime = require('./allanime');

// Simple proxy that forwards everything to allanime
class AggregatorProxy {
  constructor() {
    this.userAgent = allanime.userAgent;
    this.referer = allanime.referer;
  }

  async searchAnime(query, opts = {}) {
    return allanime.searchAnime(query, opts);
  }

  async getEpisodesList(showId) {
    // If showId has an aggregator prefix (e.g., allanime__id), strip it
    const parts = showId.split('__');
    const actualId = parts.length > 1 ? parts.slice(1).join('__') : showId;
    return allanime.getEpisodesList(actualId);
  }

  async getEpisodeEmbedUrls(showId, episodeString) {
    const parts = showId.split('__');
    const actualId = parts.length > 1 ? parts.slice(1).join('__') : showId;
    return allanime.getEpisodeEmbedUrls(actualId, episodeString);
  }

  async generateLinks(sources, showId = '') {
    return allanime.generateLinks(sources);
  }

  async getExtraMirrors(title, episodeString, originalShowId = '') {
    // Return empty since we are no longer aggregating
    return [];
  }

  selectQuality(links, preference) {
    return allanime.selectQuality(links, preference);
  }
}

module.exports = new AggregatorProxy();
